package io.github.xanderendre;

public class Main {
    public static void main(String[] args) throws Exception {
        Controller controller = new Controller();
        controller.run();
    }
}